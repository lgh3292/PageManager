/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package com.tewang.weatherforecast.pic;

/**
 *
 * @author tewang
 */
public class Pic {

}
